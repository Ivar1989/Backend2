console.log("server run")
import { pool } from './data.js'
import express from "express"
const app = express()
app.use(express.json())
app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    next();
});

app.post('/coordenadas', async (req, res) => {

    const { fecha, city, country_zone, country_name, ip, latitud, longitud, region_code, time_zone } = req.body;
  
    const [rows] = await pool.query('INSERT INTO localizacion (fecha, city, country_zone, country_name, ip, latitud, longitud, region_code, time_zone) VALUE(?,?,?,?,?,?,?,?,?)', [fecha, city, country_zone, country_name, ip, latitud, longitud, region_code, time_zone])
    res.send({
      fecha, 
      city, 
      country_zone, 
      country_name, 
      ip, 
      latitud, 
      longitud, 
      region_code, 
      time_zone
    });
    console.log("se enviaron los datos a la base de datos")
    console.log([rows])
  });

  app.delete('/coordenadas', (req, res) => res.send('Eliminando coordenadas'))

  app.get('/coordenadas',async(req,res)=>{
    const[rows]=await pool.query('SELECT * FROM localizacion;')
    res.json(rows)
  });

  app.listen(4000);

  