const API_ENDPOINT = "https://api.ipbase.com/v1/json/";

fetch(API_ENDPOINT)
    .then(response => response.json())
    .then(datosUbicacion => {
        //Imprimir los datos de la ubicación
        console.log(datosUbicacion);
        //   // Recuerda que podemos acceder a latitude y longitude, entre otros

        const city = datosUbicacion.city,
            country_zone = datosUbicacion.country_zone,
            country_name = datosUbicacion.country_name,
            ip = datosUbicacion.ip,
            latitud = datosUbicacion.latitud,
            longitud = datosUbicacion.longitud,
            region_code = datosUbicacion.region_code,
            fecha = datosUbicacion.fecha,
            time_zone = datosUbicacion.time_zone;

        console.log(`Tus coordenadas son: ${city},${country_zone},${country_name},${ip},${latitud},${longitud},${region_code},${fecha},${time_zone}`)
    })
